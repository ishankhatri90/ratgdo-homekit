# Tests for esphome-ratgdo
