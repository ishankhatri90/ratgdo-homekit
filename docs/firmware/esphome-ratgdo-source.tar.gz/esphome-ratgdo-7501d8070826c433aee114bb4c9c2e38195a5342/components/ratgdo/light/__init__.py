import esphome.codegen as cg
from esphome.components import light
import esphome.config_validation as cv
from esphome.const import CONF_OUTPUT_ID  # New in 2023.5
from esphome.types import ConfigType

from .. import RATGDO_CLIENT_SCHMEA, ratgdo_ns, register_ratgdo_child, validate_unique

DEPENDENCIES = ["ratgdo"]

RATGDOLightOutput = ratgdo_ns.class_(
    "RATGDOLightOutput", light.LightOutput, cg.Component
)


def validate_single_light(config: ConfigType) -> ConfigType:
    """Validate that only one RATGDO light is configured."""
    validate_unique("light", "ratgdo_light", "Only one RATGDO light is allowed")
    return config


CONFIG_SCHEMA = cv.All(
    light.LIGHT_SCHEMA.extend(
        {cv.GenerateID(CONF_OUTPUT_ID): cv.declare_id(RATGDOLightOutput)}
    ).extend(RATGDO_CLIENT_SCHMEA),
    validate_single_light,
)


async def to_code(config):
    var = cg.new_Pvariable(config[CONF_OUTPUT_ID])
    await cg.register_component(var, config)
    await light.register_light(var, config)
    await register_ratgdo_child(var, config)
