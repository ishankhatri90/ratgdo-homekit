#include "ratgdo_output.h"
#include "../ratgdo_state.h"
#include "esphome/core/log.h"

namespace esphome::ratgdo {

static const char* TAG = "ratgdo.output";

void RATGDOOutput::setup()
{
    ESP_LOGD(TAG, "Output was setup");

    if (this->output_type_ == OutputType::RATGDO_BEEPER) {
#ifdef RATGDO_USE_VEHICLE_SENSORS
        this->parent_->subscribe_vehicle_arriving_state([this](VehicleArrivingState state) {
            if (state == VehicleArrivingState::YES) {
                this->play();
            }
        });
#endif

        this->parent_->subscribe_door_action_delayed([this](DoorActionDelayed state) {
            if (state == DoorActionDelayed::YES) {
                this->play();
                this->repeat_ = true;
            } else if (state == DoorActionDelayed::NO) {
                this->repeat_ = false;
            }
        });
    }
}

void RATGDOOutput::play()
{
    this->beeper_->play(this->rtttlSong_);
}

void RATGDOOutput::finished_playback()
{
    if (this->repeat_)
        this->play();
}

void RATGDOOutput::dump_config()
{
    if (this->output_type_ == OutputType::RATGDO_BEEPER) {
        ESP_LOGCONFIG(TAG, "  Type: Beeper");
    }
}

void RATGDOOutput::set_output_type(OutputType output_type_)
{
    this->output_type_ = output_type_;
}

} // namespace esphome::ratgdo
